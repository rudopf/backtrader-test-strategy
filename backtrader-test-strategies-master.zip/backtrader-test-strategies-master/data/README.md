## Input Data

`btc-eur-history.csv` file contains BTC to EUR data since 2011-08-27 until 2020-01-13 (on daily basis). 
